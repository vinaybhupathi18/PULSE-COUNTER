void FLASH_WriteDevNonce(uint16_t devnonce);
uint16_t FLASH_ReadDevNonce(void);
void FLASH_reset(void);

