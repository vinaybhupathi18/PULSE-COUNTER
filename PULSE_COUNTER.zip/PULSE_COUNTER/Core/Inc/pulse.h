#include "sys_app.h"

extern  int pulse_count;
 extern uint16_t dev_nounce;
 extern  int count;

extern int flag;
