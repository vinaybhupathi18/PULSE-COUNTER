/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "i2c.h"
#include "iwdg.h"
#include "app_lorawan.h"
#include "rtc.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "LmHandler.h"
#include "LmhpCompliance.h"
#include "sys_app.h"
#include "pulse.h"
#include "lora_app.h"
#include "fram_dev.h"
volatile uint32_t last_interrupt_time = 0;
// Declare global variable for devnonce

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
int dev_flag=0;
#define DEBOUNCE_TIME_MS 50
#define FRAM_I2C_ADDRESS    0x50  // 7-bit address shifted left (0x50 << 1)
#define FRAM_PULSE_ADDR      0x00  // uses 0x00 - 0x03 (4 bytes)
#define FRAM_TIMEOUT        1000  // I2C timeout in ms
HAL_StatusTypeDef FRAM_WriteData(uint16_t mem_addr, uint8_t* data, uint16_t size);
HAL_StatusTypeDef FRAM_ReadData(uint16_t mem_addr, uint8_t* data, uint16_t size);
int FRAM_ReadPulseCount(void);
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
HAL_StatusTypeDef FRAM_WriteData(uint16_t mem_addr, uint8_t* data, uint16_t size)
{
    return HAL_I2C_Mem_Write(&hi2c2, FRAM_I2C_ADDRESS << 1, mem_addr, I2C_MEMADD_SIZE_8BIT, data, size, FRAM_TIMEOUT);
}

HAL_StatusTypeDef FRAM_ReadData(uint16_t mem_addr, uint8_t* data, uint16_t size)
{
    return HAL_I2C_Mem_Read(&hi2c2, FRAM_I2C_ADDRESS << 1, mem_addr, I2C_MEMADD_SIZE_8BIT, data, size, FRAM_TIMEOUT);
}

void FRAM_WritePulseCount(int count)
{
    uint8_t data[4];
    data[0] = (count >> 24) & 0xFF;  // MSB
    data[1] = (count >> 16) & 0xFF;
    data[2] = (count >> 8) & 0xFF;
    data[3] = count & 0xFF;          // LSB

    HAL_StatusTypeDef status = FRAM_WriteData(FRAM_PULSE_ADDR, data, 4);
    if (status != HAL_OK)
    {
    	APP_LOG(TS_ON,VLEVEL_H,"FRAM Write Error\r\n");
       // char error_msg[] = "FRAM Write Error\r\n";
       // HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
    }
}

int FRAM_ReadPulseCount(void)
{
    uint8_t data[4];
    HAL_StatusTypeDef status = FRAM_ReadData(FRAM_PULSE_ADDR, data, 4);
    if (status == HAL_OK)
    {
        count = (data[0] << 24) | (data[1] << 16) | (data[2] << 8) | data[3];
    }
    else
    {
    	 uint32_t errorCode = HAL_I2C_GetError(&hi2c2);

    	    APP_LOG(TS_ON, VLEVEL_H, "FRAM read error! I2C error code: 0x%08lX\r\n", errorCode);

    	    switch (errorCode)
    	    {
    	        case HAL_I2C_ERROR_NONE:
    	            APP_LOG(TS_ON, VLEVEL_H, "I2C OK\r\n");
    	            break;
    	        case HAL_I2C_ERROR_BERR:
    	            APP_LOG(TS_ON, VLEVEL_H, "Bus Error\r\n");
    	            break;
    	        case HAL_I2C_ERROR_ARLO:
    	            APP_LOG(TS_ON, VLEVEL_H, "Arbitration Lost\r\n");
    	            break;
    	        case HAL_I2C_ERROR_AF:
    	            APP_LOG(TS_ON, VLEVEL_H, "Acknowledge Failure\r\n");
    	            break;
    	        case HAL_I2C_ERROR_OVR:
    	            APP_LOG(TS_ON, VLEVEL_H, "Overrun/Underrun\r\n");
    	            break;
    	        case HAL_I2C_ERROR_DMA:
    	            APP_LOG(TS_ON, VLEVEL_H, "DMA Transfer Error\r\n");
    	            break;
    	        case HAL_I2C_ERROR_TIMEOUT:
    	            APP_LOG(TS_ON, VLEVEL_H, "Timeout\r\n");
    	            break;
    	        default:
    	            APP_LOG(TS_ON, VLEVEL_H, "Unknown I2C error\r\n");
    	            break;
    	    }
    }

    return count;
}

void pulse_counter()
{
    pulse_count++;
    FRAM_WritePulseCount(pulse_count);
    APP_LOG(TS_ON,VLEVEL_H,"Pulse Count: %d\r\n",pulse_count);
}
void FRAM_ResetPulseCount(void)
{
    pulse_count = 0;
    FRAM_WritePulseCount(pulse_count);
   APP_LOG(TS_ON,VLEVEL_H,"pulse count %d\r\n",pulse_count);

}


/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  if (__HAL_RCC_GET_FLAG(RCC_FLAG_IWDGRST) != RESET)
  {
      APP_LOG(TS_ON, VLEVEL_H, "IWDG Reset occurred\r\n");
      __HAL_RCC_CLEAR_RESET_FLAGS();
  }

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC_Init();
  MX_RTC_Init();
  MX_USART2_UART_Init();
//  HAL_Delay(2000);
  MX_I2C2_Init();
//  HAL_Delay(2000);
  MX_LoRaWAN_Init();
//  MX_IWDG_Init();
  /* USER CODE BEGIN 2 */
  APP_LOG(TS_ON, VLEVEL_H, "RAK3172 Counter Started\r\n");
  APP_LOG(TS_ON, VLEVEL_H, " LoRaWAN stack initialized. Attempting to join the network...\r\n");
    HAL_Delay(4000);
    pulse_count = FRAM_ReadPulseCount();
    MX_IWDG_Init();
    APP_LOG(TS_ON, VLEVEL_H, " Pulse Count restored from FRAM: %d\r\n", pulse_count);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
    MX_LoRaWAN_Process();

    /* USER CODE BEGIN 3 */
       //HAL_Delay(2000);
            flag=0;
            APP_LOG(TS_ON, VLEVEL_H, " System Running... Current Pulse Count: %d\r\n", pulse_count);
   	    HAL_Delay(1000);
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_LSE
                              |RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = RCC_MSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_11;
  RCC_OscInitStruct.LSIDiv = RCC_LSI_DIV1;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure the SYSCLKSource, HCLK, PCLK1 and PCLK2 clocks dividers
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK3|RCC_CLOCKTYPE_HCLK
                              |RCC_CLOCKTYPE_SYSCLK|RCC_CLOCKTYPE_PCLK1
                              |RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.AHBCLK3Divider = RCC_SYSCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if (GPIO_Pin == GPIO_PIN_7)
    {
        uint32_t current_time = HAL_GetTick();
        if ((current_time - last_interrupt_time) >= DEBOUNCE_TIME_MS)
        {
            last_interrupt_time = current_time;
            pulse_counter();
        }
    }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
