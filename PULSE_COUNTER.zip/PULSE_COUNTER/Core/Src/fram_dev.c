/**
 * @brief Updated FRAM DevNonce functions for 16-bit DevNonce
 * 
 * DevNonce should be 16-bit as per LoRaWAN specification
 * Memory layout: 2 bytes at FRAM_DEVNONCE_ADDR
 */

// Update the FRAM address definition
//#define FRAM_DEVNONCE_ADDR   0x04  // DevNonce storage (2 bytes)

/**
 * @brief Write 16-bit DevNonce to FRAM
 * @param devnonce: 16-bit DevNonce value to store
 */
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "i2c.h"
#include "app_lorawan.h"
#include "rtc.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "LmHandler.h"
#include "LmhpCompliance.h"
#include "sys_app.h"
#include "pulse.h"
#include "stm32wlxx_hal_flash.h"

#include "lora_app.h"

void FLASH_WriteDevNonce(uint16_t devnonce)
{
    HAL_FLASH_Unlock();

    // Erase page before writing (only needed once if using full page for config)
    FLASH_EraseInitTypeDef eraseConfig;
    uint32_t pageError = 0;

    eraseConfig.TypeErase = FLASH_TYPEERASE_PAGES;
    eraseConfig.Page = (FLASH_DEVNONCE_ADDR - 0x08000000) / FLASH_PAGE_SIZE;
   // eraseConfig.Banks = FLASH_BANK_1;
    eraseConfig.NbPages = 1;

    if (HAL_FLASHEx_Erase(&eraseConfig, &pageError) != HAL_OK)
    {
        APP_LOG(TS_ON, VLEVEL_H, " Flash erase failed!\r\n");
        HAL_FLASH_Lock();
        return;
    }

    // Flash supports 64-bit (8 byte) programming only
    uint64_t data64 = (uint64_t)devnonce;  // upper 6 bytes = 0
    if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_DOUBLEWORD, FLASH_DEVNONCE_ADDR, data64) != HAL_OK)
    {
        APP_LOG(TS_ON, VLEVEL_H, " [FLASH] Failed to write DevNonce to address 0x%08lX\r\n", FLASH_DEVNONCE_ADDR);
    }
    else
    {
        APP_LOG(TS_ON, VLEVEL_H, " [FLASH] DevNonce written successfully: %u (0x%08lX)\r\n", devnonce, FLASH_DEVNONCE_ADDR);
    }

    HAL_FLASH_Lock();
}
void FLASH_reset(void)
{
	FLASH_WriteDevNonce(0);
//    HAL_FLASH_Unlock();
//    FLASH_EraseInitTypeDef eraseConfig;
//    uint32_t pageError = 0;
//    eraseConfig.TypeErase = FLASH_TYPEERASE_PAGES;
//      eraseConfig.Page = (FLASH_DEVNONCE_ADDR - 0x08000000) / FLASH_PAGE_SIZE;
//     // eraseConfig.Banks = FLASH_BANK_1;
//      eraseConfig.NbPages = 1;
//    if (HAL_FLASHEx_Erase(&eraseConfig, &pageError) != HAL_OK)
//       {
//           APP_LOG(TS_ON, VLEVEL_H, " Flash erase failed!\r\n");
//           HAL_FLASH_Lock();
//           return;

//       }
//    uint64_t data64 = 0;
//        if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_DOUBLEWORD, FLASH_DEVNONCE_ADDR, data64) != HAL_OK)
//        {
//            APP_LOG(TS_ON, VLEVEL_H, " Flash Erase failed!\r\n");
//        }
//        else
//        {
//           APP_LOG(TS_ON, VLEVEL_H, " flash reset to : %u\r\n", data64);
//        }
//
//    HAL_FLASH_Lock();
}
uint16_t FLASH_ReadDevNonce(void)
{
	uint64_t stored = *(volatile uint64_t*)FLASH_DEVNONCE_ADDR;
	    return (uint16_t)(stored & 0xFFFF);
}

