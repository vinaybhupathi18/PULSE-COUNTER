#include "pulse.h"
 int pulse_count = 0;
uint16_t dev_nounce=0;
int flag=0;
int count = 0;
